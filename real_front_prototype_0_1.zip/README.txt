REAL FRONT — Prototype 0.1
============================
This is the first browser-playable prototype.

Included:
- Player movement
- Mobile touch controls
- Basic enemy AI/detection
- Hide/stealth toggle
- Basic firing/ammunition
- Health and death
- Civilians
- Simple terrain/road presentation
- Level 1 shell

Controls:
Phone: touch movement buttons, FIRE, HIDE, RESET.
Keyboard: WASD/arrow keys, SPACE to fire, H to hide.

Next development targets:
1. Replace prototype visuals with proper 3D assets.
2. Add real vehicle enter/exit.
3. Add inventory and weapon economy.
4. Add mission objectives and Level 1 completion.
5. Build the 100-level campaign.
6. Add online multiplayer/team warfare later.
